# Agente Bancario IA Nota 10
Projeto com FastAPI, JWT, SQLite, Docker, testes e CI/CD.